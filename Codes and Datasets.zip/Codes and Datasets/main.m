clc
clear
close all

%% load data
% load '\Datasets\susytraintest' ; I = 18; name='SUSY'; 
% load '\Datasets\sea'; I = 3; name='Sea';
 load '\Datasets\electricitypricing'; I = 8; name='Electricity';
% load '\Datasets\PMnist'; I = 784; name='Permuted MNIST';
% load '\Datasets\RMnist'; I = 784; name='Rotated MNIST';
% load '\Datasets\datahyp'; I = 4; name='Hyperplane';

%% run proposed SMURT
[parameter,performance] = musernn(data,I,name);
disp(performance)

